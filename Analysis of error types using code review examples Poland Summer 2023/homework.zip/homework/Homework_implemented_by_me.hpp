#ifndef MYVECTORCORRECTED_HPP
#define MYVECTORCORRECTED_HPP

#include <vector>
#include <string>
#include <memory>
#include <utility>
#include <stdexcept>
#include <algorithm>

template <typename T>
class MyVector {
private:
    struct SharedData {
        std::vector<std::pair<T, std::string>> data;
        SharedData() = default;
        SharedData(const SharedData& other) : data(other.data) {}
    };

    std::shared_ptr<SharedData> m_sharedData;
    using value_type = std::pair<T, std::string>;
    using allocator_type = std::allocator<value_type>;
    using reference = value_type&;
    using const_reference = const value_type&;  
    using pointer = typename std::allocator<value_type>::pointer;
    using const_pointer = typename std::allocator<value_type>::const_pointer;
    using iterator = typename std::vector<value_type>::iterator;
    using const_iterator = typename std::vector<value_type>::const_iterator;
    using reverse_iterator = std::reverse_iterator<iterator>;
    using const_reverse_iterator = std::reverse_iterator<const_iterator>;
    using size_type = std::size_t;
    using difference_type = ptrdiff_t;

    void copy_on_write() {
        if (m_sharedData.use_count() > 1) {
            m_sharedData = std::make_shared<SharedData>(*m_sharedData);
        }
    }

public:
        MyVector() : m_sharedData(std::make_shared<SharedData>()) {}

    std::pair<const T&, const std::string&> operator[](int index) const {
        if (index < 0 || static_cast<size_t>(index) >= m_sharedData->data.size()) {
            throw std::out_of_range("Index out of range");
        }
        const auto& pair = m_sharedData->data[index];
        return {pair.first, pair.second};
    }
    
    std::pair<T&, std::string&> operator[](int index) {
        copy_on_write();

        if (index < 0 || static_cast<size_t>(index) >= m_sharedData->data.size()) {
            throw std::out_of_range("Index out of range");
        }
        auto& pair = m_sharedData->data[index];
        return {pair.first, pair.second};
    }

    T& operator[](const std::string& name) {
        copy_on_write();

        for (auto& pair : m_sharedData->data) {
            if (pair.second == name) {
                return pair.first;
            }
        }
        throw std::out_of_range("Name not found in MyVector");
    }

    const T& operator[](const std::string& name) const {
        for (const auto& pair : m_sharedData->data) {
            if (pair.second == name) return pair.first;
        }
        throw std::invalid_argument(name + " not found");
    }

    void push_back(const T& value, const std::string& name) {
        copy_on_write();
        m_sharedData->data.push_back({ value, name });
    }

    iterator begin() { 
        copy_on_write(); 
        return m_sharedData->data.begin(); 
    }
    const_iterator begin() const { 
        return m_sharedData->data.begin(); 
    }
    const_iterator cbegin() const { 
        return m_sharedData->data.cbegin(); 
    }
    iterator end() { 
        copy_on_write(); 
        return m_sharedData->data.end(); 
    }
    const_iterator end() const { 
        return m_sharedData->data.end(); 
    }
    const_iterator cend() const { 
        return m_sharedData->data.cend(); 
    }
    size_type size() const { 
        return m_sharedData->data.size(); 
    }
    bool empty() const { 
        return m_sharedData->data.empty(); 
    }
    void reserve(size_type capacity) { 
        copy_on_write();
        m_sharedData->data.reserve(capacity); 
    }
    void clear() { 
        copy_on_write();
        m_sharedData->data.clear(); 
    }

};

#endif // MYVECTORCORRECTED_HPP
