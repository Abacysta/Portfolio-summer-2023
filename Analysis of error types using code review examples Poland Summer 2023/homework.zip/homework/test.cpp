#include "Homework_implemented_by_me.hpp"
#include <iostream>
#include <cassert>

int main() {
    MyVector<int> vec;

    assert(vec.empty());
    assert(vec.size() == 0);

    vec.push_back(1, "one");
    vec.push_back(2, "two");
    vec.push_back(3, "three");
    assert(!vec.empty());
    assert(vec.size() == 3);

    assert(vec[0].first == 1);
    assert(vec[0].second == "one");

    assert(vec[1].first == 2);
    assert(vec[1].second == "two");

    assert(vec[2].first == 3);
    assert(vec[2].second == "three");

    assert(vec["one"] == 1);
    assert(vec["two"] == 2);
    assert(vec["three"] == 3);

    vec["one"] = 10;
    assert(vec["one"] == 10);

    vec[1].first = 20;
    vec[1].second = "twenty";

    assert(vec["twenty"] == 20);
    assert(vec[1].second == "twenty");

    std::cout << "value for 'one': " << vec["one"] << std::endl;
    std::cout << "value for 'twenty': " << vec["twenty"] << std::endl;

    auto it = vec.begin();
    assert(it->first == 10);
    assert(it->second == "one");
    std::cout << "via iterator: " << it->first << ", " << it->second << std::endl;

    vec.clear();
    assert(vec.empty());
    assert(vec.size() == 0);

    std::cout << "All tests passed!" << std::endl;

    return 0;
}